start cli.exe re.txt
